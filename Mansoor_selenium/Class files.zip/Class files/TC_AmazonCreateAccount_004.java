package com.qa.testsScripts;

import org.testng.annotations.Test;

public class TC_AmazonCreateAccount_004 extends TestBase {
	
	
	
	
	@Test
	public void createAccount(){
		
	}
	
	
	

}
